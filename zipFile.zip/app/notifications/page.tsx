"use client";

import { ArrowLeft, Bell, Trophy, MessageCircle, Target, Flame } from "lucide-react";
import Link from "next/link";
import { BottomNav } from "@/components/bottom-nav";

const notifications = [
  {
    id: 1,
    icon: Flame,
    title: "Keep your streak alive!",
    message: "Complete today's lesson to maintain your 24-day streak",
    time: "2 hours ago",
    unread: true,
  },
  {
    id: 2,
    icon: Trophy,
    title: "Achievement Unlocked!",
    message: "You earned 'Early Bird' for completing 5 morning lessons",
    time: "Yesterday",
    unread: true,
  },
  {
    id: 3,
    icon: Target,
    title: "Goal Progress",
    message: "You're 60% towards your savings goal!",
    time: "2 days ago",
    unread: false,
  },
  {
    id: 4,
    icon: MessageCircle,
    title: "New AI Feature",
    message: "Try our new personalized coaching chat",
    time: "3 days ago",
    unread: false,
  },
];

export default function NotificationsPage() {
  return (
    <div className="flex min-h-screen flex-col bg-background pb-20">
      <header className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-xl">
        <div className="flex items-center gap-4 px-4 py-3">
          <Link
            href="/"
            className="flex size-10 items-center justify-center rounded-full bg-secondary text-muted-foreground transition-colors hover:bg-secondary/80"
          >
            <ArrowLeft className="size-5" />
          </Link>
          <div className="flex-1">
            <h1 className="text-lg font-bold text-foreground">Notifications</h1>
          </div>
          <Bell className="size-5 text-primary" />
        </div>
      </header>

      <main className="flex-1 px-4 py-6">
        <div className="flex flex-col gap-3">
          {notifications.map((notification) => {
            const Icon = notification.icon;
            return (
              <button
                key={notification.id}
                className={`flex items-start gap-3 rounded-xl border p-4 text-left transition-all hover:border-primary/50 active:scale-[0.98] ${
                  notification.unread
                    ? "border-primary/30 bg-primary/5"
                    : "border-border bg-card"
                }`}
              >
                <div
                  className={`flex size-10 shrink-0 items-center justify-center rounded-full ${
                    notification.unread
                      ? "bg-primary text-primary-foreground"
                      : "bg-secondary text-muted-foreground"
                  }`}
                >
                  <Icon className="size-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="font-medium text-foreground">{notification.title}</h3>
                    {notification.unread && (
                      <span className="size-2 shrink-0 rounded-full bg-primary" />
                    )}
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground line-clamp-2">
                    {notification.message}
                  </p>
                  <p className="mt-2 text-xs text-muted-foreground">{notification.time}</p>
                </div>
              </button>
            );
          })}
        </div>

        {notifications.length === 0 && (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <Bell className="size-12 text-muted-foreground" />
            <h3 className="mt-4 font-medium text-foreground">No notifications</h3>
            <p className="mt-1 text-sm text-muted-foreground">
              You&apos;re all caught up!
            </p>
          </div>
        )}
      </main>

      <BottomNav />
    </div>
  );
}
