"use client";

import { ArrowLeft, User, Settings, ChevronRight, Trophy, Flame, BookOpen, LogOut, Crown } from "lucide-react";
import Link from "next/link";
import { BottomNav } from "@/components/bottom-nav";

const menuItems = [
  { icon: Crown, label: "Go Premium", href: "/subscription", highlight: true },
  { icon: Settings, label: "Settings", href: "/settings" },
  { icon: Trophy, label: "Achievements", href: "/achievements" },
  { icon: BookOpen, label: "My Learning", href: "/learning" },
];

export default function ProfilePage() {
  return (
    <div className="flex min-h-screen flex-col bg-background pb-20">
      <header className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-xl">
        <div className="flex items-center gap-4 px-4 py-3">
          <Link
            href="/"
            className="flex size-10 items-center justify-center rounded-full bg-secondary text-muted-foreground transition-colors hover:bg-secondary/80"
          >
            <ArrowLeft className="size-5" />
          </Link>
          <h1 className="text-lg font-bold text-foreground">Profile</h1>
        </div>
      </header>

      <main className="flex-1 px-4 py-6">
        <div className="flex flex-col items-center text-center">
          <div className="flex size-24 items-center justify-center rounded-full bg-primary text-primary-foreground">
            <User className="size-12" />
          </div>
          <h2 className="mt-4 text-xl font-bold text-foreground">Arjun Sharma</h2>
          <p className="text-sm text-muted-foreground">arjun@example.com</p>
          <div className="mt-2 flex items-center gap-1 rounded-full bg-primary/10 px-3 py-1">
            <Flame className="size-4 text-primary" />
            <span className="text-sm font-medium text-primary">Level 12</span>
          </div>
        </div>

        <div className="mt-8 grid grid-cols-3 gap-3">
          <div className="rounded-xl border border-border bg-card p-4 text-center">
            <p className="text-2xl font-bold text-foreground">24</p>
            <p className="text-xs text-muted-foreground">Day Streak</p>
          </div>
          <div className="rounded-xl border border-border bg-card p-4 text-center">
            <p className="text-2xl font-bold text-foreground">156</p>
            <p className="text-xs text-muted-foreground">Lessons</p>
          </div>
          <div className="rounded-xl border border-border bg-card p-4 text-center">
            <p className="text-2xl font-bold text-foreground">2.4k</p>
            <p className="text-xs text-muted-foreground">XP Points</p>
          </div>
        </div>

        <div className="mt-8 flex flex-col gap-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isHighlight = 'highlight' in item && item.highlight;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center justify-between rounded-xl border p-4 transition-all active:scale-[0.98] ${
                  isHighlight 
                    ? "border-primary bg-primary/10 hover:bg-primary/20" 
                    : "border-border bg-card hover:border-primary/50"
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`size-5 ${isHighlight ? "text-primary" : "text-muted-foreground"}`} />
                  <span className={`font-medium ${isHighlight ? "text-primary" : "text-foreground"}`}>{item.label}</span>
                </div>
                <ChevronRight className={`size-5 ${isHighlight ? "text-primary" : "text-muted-foreground"}`} />
              </Link>
            );
          })}
        </div>

        <Link
          href="/login"
          className="mt-8 flex w-full items-center justify-center gap-2 rounded-xl border border-destructive/50 bg-destructive/10 p-4 text-destructive transition-all hover:bg-destructive/20 active:scale-[0.98]"
        >
          <LogOut className="size-5" />
          <span className="font-medium">Sign Out</span>
        </Link>
      </main>

      <BottomNav />
    </div>
  );
}
