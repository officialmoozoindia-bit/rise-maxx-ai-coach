"use client";

import { ArrowLeft, CheckCircle2, Circle, Flame, Trophy, Zap } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { BottomNav } from "@/components/bottom-nav";

interface Challenge {
  id: number;
  title: string;
  xp: number;
  completed: boolean;
}

const initialChallenges: Challenge[] = [
  { id: 1, title: "Complete 1 lesson from any category", xp: 50, completed: true },
  { id: 2, title: "Read a financial tip of the day", xp: 20, completed: true },
  { id: 3, title: "Do a 5-minute breathing exercise", xp: 30, completed: false },
  { id: 4, title: "Log your workout or physical activity", xp: 40, completed: false },
  { id: 5, title: "Update progress on one of your goals", xp: 25, completed: false },
];

export default function DailyChallengePage() {
  const [challenges, setChallenges] = useState<Challenge[]>(initialChallenges);
  const completedCount = challenges.filter((c) => c.completed).length;
  const totalXP = challenges.filter((c) => c.completed).reduce((sum, c) => sum + c.xp, 0);
  const maxXP = challenges.reduce((sum, c) => sum + c.xp, 0);

  const toggleChallenge = (id: number) => {
    setChallenges((prev) =>
      prev.map((c) => (c.id === id ? { ...c, completed: !c.completed } : c))
    );
  };

  return (
    <div className="flex min-h-screen flex-col bg-background pb-20">
      <header className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-xl">
        <div className="flex items-center gap-4 px-4 py-3">
          <Link
            href="/"
            className="flex size-10 items-center justify-center rounded-full bg-secondary text-muted-foreground transition-colors hover:bg-secondary/80"
          >
            <ArrowLeft className="size-5" />
          </Link>
          <div className="flex-1">
            <h1 className="text-lg font-bold text-foreground">Daily Challenge</h1>
            <p className="text-xs text-muted-foreground">{completedCount} of {challenges.length} completed</p>
          </div>
          <div className="flex items-center gap-1 rounded-full bg-primary/10 px-3 py-1">
            <Flame className="size-4 text-primary" />
            <span className="text-sm font-medium text-primary">Day 24</span>
          </div>
        </div>
      </header>

      <main className="flex-1 px-4 py-6">
        <div className="mb-6 rounded-xl border border-primary/30 bg-gradient-to-br from-primary/20 via-primary/10 to-transparent p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Today&apos;s XP</p>
              <p className="text-3xl font-bold text-foreground">
                {totalXP} <span className="text-lg text-muted-foreground">/ {maxXP}</span>
              </p>
            </div>
            <div className="flex size-16 items-center justify-center rounded-full bg-primary/20">
              <Trophy className="size-8 text-primary" />
            </div>
          </div>
          <div className="mt-4 h-2 rounded-full bg-secondary">
            <div
              className="h-full rounded-full bg-primary transition-all"
              style={{ width: `${(totalXP / maxXP) * 100}%` }}
            />
          </div>
        </div>

        <h2 className="mb-4 font-semibold text-foreground">Today&apos;s Tasks</h2>

        <div className="flex flex-col gap-3">
          {challenges.map((challenge) => (
            <button
              key={challenge.id}
              onClick={() => toggleChallenge(challenge.id)}
              className={`flex items-center gap-3 rounded-xl border p-4 text-left transition-all active:scale-[0.98] ${
                challenge.completed
                  ? "border-primary/30 bg-primary/5"
                  : "border-border bg-card hover:border-primary/50"
              }`}
            >
              <div
                className={`flex size-6 items-center justify-center rounded-full transition-colors ${
                  challenge.completed ? "text-primary" : "text-muted-foreground"
                }`}
              >
                {challenge.completed ? (
                  <CheckCircle2 className="size-6" />
                ) : (
                  <Circle className="size-6" />
                )}
              </div>
              <div className="flex-1">
                <p
                  className={`font-medium ${
                    challenge.completed
                      ? "text-muted-foreground line-through"
                      : "text-foreground"
                  }`}
                >
                  {challenge.title}
                </p>
              </div>
              <div className="flex items-center gap-1 rounded-full bg-secondary px-2 py-1">
                <Zap className="size-3 text-primary" />
                <span className="text-xs font-medium text-muted-foreground">
                  +{challenge.xp} XP
                </span>
              </div>
            </button>
          ))}
        </div>

        {completedCount === challenges.length && (
          <div className="mt-6 rounded-xl border border-primary bg-primary/10 p-4 text-center">
            <Trophy className="mx-auto size-12 text-primary" />
            <h3 className="mt-2 text-lg font-bold text-foreground">
              All challenges completed!
            </h3>
            <p className="mt-1 text-sm text-muted-foreground">
              Amazing work! You earned {maxXP} XP today.
            </p>
          </div>
        )}
      </main>

      <BottomNav />
    </div>
  );
}
