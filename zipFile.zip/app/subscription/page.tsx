"use client";

import { ArrowLeft, Check, X, Crown, Zap, Sparkles, Shield, MessageCircle, Target, Brain, Star } from "lucide-react";
import Link from "next/link";
import { useState } from "react";

const plans = [
  {
    id: "free",
    name: "Free",
    price: "₹0",
    period: "forever",
    description: "Get started on your self-improvement journey",
    features: [
      { name: "5 AI chat messages/day", included: true },
      { name: "Basic lessons access", included: true },
      { name: "Goals tracker (3 goals)", included: true },
      { name: "Daily motivational quotes", included: true },
      { name: "Community access", included: true },
      { name: "Unlimited AI coaching", included: false },
      { name: "All premium lessons", included: false },
      { name: "Personalized workout plans", included: false },
      { name: "Mental health journal", included: false },
      { name: "Priority support", included: false },
    ],
    cta: "Current Plan",
    popular: false,
    disabled: true,
  },
  {
    id: "pro",
    name: "Pro",
    price: "₹99",
    period: "/month",
    description: "Unlock your full potential with unlimited access",
    features: [
      { name: "Unlimited AI chat messages", included: true },
      { name: "All premium lessons", included: true },
      { name: "Unlimited goals", included: true },
      { name: "Daily motivational quotes", included: true },
      { name: "Exclusive community", included: true },
      { name: "Personalized workout plans", included: true },
      { name: "Custom diet plans (Indian)", included: true },
      { name: "Mental health journal", included: true },
      { name: "1-on-1 AI coaching sessions", included: true },
      { name: "Priority support", included: true },
    ],
    cta: "Upgrade to Pro",
    popular: true,
    disabled: false,
  },
];

const testimonials = [
  {
    name: "Arjun S.",
    age: 17,
    location: "Mumbai",
    text: "RiseMaxx Pro helped me build better habits during JEE prep. The mental health tips are gold!",
    rating: 5,
  },
  {
    name: "Priya M.",
    age: 16,
    location: "Delhi",
    text: "The personalized workout plans fit perfectly with my school schedule. Lost 5kg in 2 months!",
    rating: 5,
  },
  {
    name: "Rahul K.",
    age: 18,
    location: "Bangalore",
    text: "Started my first side hustle thanks to the Money & Business lessons. Making ₹5k/month now!",
    rating: 5,
  },
];

const proFeatures = [
  {
    icon: <MessageCircle className="size-5" />,
    title: "Unlimited AI Chat",
    description: "Ask anything, anytime. No daily limits.",
  },
  {
    icon: <Brain className="size-5" />,
    title: "Mental Health Journal",
    description: "Track your mood and get AI insights.",
  },
  {
    icon: <Target className="size-5" />,
    title: "Personalized Plans",
    description: "Workout and diet plans for Indian teens.",
  },
  {
    icon: <Shield className="size-5" />,
    title: "Priority Support",
    description: "Get help within 24 hours, guaranteed.",
  },
];

export default function SubscriptionPage() {
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubscribe = async (planId: string) => {
    if (planId === "free") return;
    
    setSelectedPlan(planId);
    setIsProcessing(true);
    
    // Simulate payment processing
    await new Promise((resolve) => setTimeout(resolve, 2000));
    
    setIsProcessing(false);
    // In production, redirect to payment gateway
    alert("Redirecting to payment gateway...");
  };

  return (
    <div className="flex min-h-screen flex-col bg-background pb-8">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-xl">
        <div className="flex items-center gap-4 px-4 py-3">
          <Link
            href="/profile"
            className="flex size-10 items-center justify-center rounded-full bg-secondary text-muted-foreground transition-colors hover:bg-secondary/80"
          >
            <ArrowLeft className="size-5" />
          </Link>
          <div>
            <h1 className="text-lg font-bold text-foreground">Go Premium</h1>
            <p className="text-xs text-muted-foreground">Unlock your full potential</p>
          </div>
        </div>
      </header>

      <main className="flex-1 px-4 pt-6">
        {/* Hero Section */}
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 flex size-16 items-center justify-center rounded-full bg-primary/20">
            <Crown className="size-8 text-primary" />
          </div>
          <h2 className="mb-2 text-2xl font-bold text-foreground">
            Level Up Your Life
          </h2>
          <p className="text-muted-foreground">
            Join 10,000+ Indian teens transforming their lives with RiseMaxx Pro
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="mb-8 flex flex-col gap-4">
          {plans.map((plan) => (
            <div
              key={plan.id}
              className={`relative overflow-hidden rounded-2xl border-2 p-6 transition-all ${
                plan.popular
                  ? "border-primary bg-primary/5"
                  : "border-border bg-card"
              }`}
            >
              {plan.popular && (
                <div className="absolute right-0 top-0">
                  <div className="flex items-center gap-1 rounded-bl-xl bg-primary px-3 py-1">
                    <Sparkles className="size-3 text-primary-foreground" />
                    <span className="text-xs font-semibold text-primary-foreground">
                      MOST POPULAR
                    </span>
                  </div>
                </div>
              )}

              <div className="mb-4">
                <h3 className="text-lg font-bold text-foreground">{plan.name}</h3>
                <p className="text-sm text-muted-foreground">{plan.description}</p>
              </div>

              <div className="mb-6 flex items-baseline gap-1">
                <span className="text-4xl font-bold text-foreground">
                  {plan.price}
                </span>
                <span className="text-muted-foreground">{plan.period}</span>
              </div>

              <ul className="mb-6 flex flex-col gap-3">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-center gap-3">
                    {feature.included ? (
                      <div className="flex size-5 items-center justify-center rounded-full bg-primary/20">
                        <Check className="size-3 text-primary" />
                      </div>
                    ) : (
                      <div className="flex size-5 items-center justify-center rounded-full bg-muted">
                        <X className="size-3 text-muted-foreground" />
                      </div>
                    )}
                    <span
                      className={
                        feature.included
                          ? "text-foreground"
                          : "text-muted-foreground line-through"
                      }
                    >
                      {feature.name}
                    </span>
                  </li>
                ))}
              </ul>

              <button
                onClick={() => handleSubscribe(plan.id)}
                disabled={plan.disabled || isProcessing}
                className={`flex w-full items-center justify-center gap-2 rounded-xl py-4 font-semibold transition-all active:scale-[0.98] ${
                  plan.popular
                    ? "bg-primary text-primary-foreground hover:opacity-90"
                    : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                } ${plan.disabled ? "cursor-not-allowed opacity-50" : ""}`}
              >
                {isProcessing && selectedPlan === plan.id ? (
                  <>
                    <div className="size-5 animate-spin rounded-full border-2 border-current border-t-transparent" />
                    <span>Processing...</span>
                  </>
                ) : (
                  <>
                    {plan.popular && <Zap className="size-5" />}
                    <span>{plan.cta}</span>
                  </>
                )}
              </button>
            </div>
          ))}
        </div>

        {/* Pro Features Grid */}
        <div className="mb-8">
          <h3 className="mb-4 text-lg font-bold text-foreground">
            What You Get with Pro
          </h3>
          <div className="grid grid-cols-2 gap-3">
            {proFeatures.map((feature, index) => (
              <div
                key={index}
                className="flex flex-col gap-2 rounded-xl border border-border bg-card p-4"
              >
                <div className="flex size-10 items-center justify-center rounded-full bg-primary/20 text-primary">
                  {feature.icon}
                </div>
                <h4 className="font-semibold text-foreground">{feature.title}</h4>
                <p className="text-xs text-muted-foreground">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Testimonials */}
        <div className="mb-8">
          <h3 className="mb-4 text-lg font-bold text-foreground">
            What Teens Are Saying
          </h3>
          <div className="flex flex-col gap-4">
            {testimonials.map((testimonial, index) => (
              <div
                key={index}
                className="rounded-xl border border-border bg-card p-4"
              >
                <div className="mb-2 flex items-center gap-1">
                  {Array.from({ length: testimonial.rating }).map((_, i) => (
                    <Star
                      key={i}
                      className="size-4 fill-primary text-primary"
                    />
                  ))}
                </div>
                <p className="mb-3 text-sm text-foreground">
                  &quot;{testimonial.text}&quot;
                </p>
                <div className="text-xs text-muted-foreground">
                  <span className="font-medium text-foreground">
                    {testimonial.name}
                  </span>
                  , {testimonial.age} • {testimonial.location}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* FAQ Preview */}
        <div className="mb-8 rounded-xl border border-border bg-card p-4">
          <h3 className="mb-3 font-bold text-foreground">
            Frequently Asked Questions
          </h3>
          <div className="flex flex-col gap-3">
            <div>
              <p className="text-sm font-medium text-foreground">
                Can I cancel anytime?
              </p>
              <p className="text-xs text-muted-foreground">
                Yes! Cancel anytime from your profile. No questions asked.
              </p>
            </div>
            <div>
              <p className="text-sm font-medium text-foreground">
                Is my payment secure?
              </p>
              <p className="text-xs text-muted-foreground">
                100% secure. We use Razorpay with bank-level encryption.
              </p>
            </div>
            <div>
              <p className="text-sm font-medium text-foreground">
                Can my parents pay?
              </p>
              <p className="text-xs text-muted-foreground">
                Absolutely! UPI, cards, and net banking all accepted.
              </p>
            </div>
          </div>
        </div>

        {/* Money Back Guarantee */}
        <div className="rounded-xl border border-primary/50 bg-primary/10 p-4 text-center">
          <Shield className="mx-auto mb-2 size-8 text-primary" />
          <h3 className="mb-1 font-bold text-foreground">
            7-Day Money Back Guarantee
          </h3>
          <p className="text-sm text-muted-foreground">
            Not satisfied? Get a full refund within 7 days. No questions asked.
          </p>
        </div>
      </main>
    </div>
  );
}
