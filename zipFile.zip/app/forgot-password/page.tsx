"use client";

import { useState } from "react";
import Link from "next/link";
import { Flame, Mail, ArrowLeft, CheckCircle } from "lucide-react";

export default function ForgotPasswordPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000));
    setIsSubmitted(true);
    setIsLoading(false);
  };

  return (
    <main className="flex min-h-screen flex-col bg-background">
      <div className="flex flex-1 flex-col items-center justify-center px-6 py-12">
        {/* Logo */}
        <div className="mb-8 flex flex-col items-center">
          <div className="mb-4 flex size-16 items-center justify-center rounded-2xl bg-primary">
            <Flame className="size-9 text-primary-foreground" />
          </div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">
            Reset Password
          </h1>
          <p className="mt-2 text-center text-muted-foreground">
            {isSubmitted
              ? "Check your email for reset instructions"
              : "Enter your email to receive a reset link"}
          </p>
        </div>

        {/* Form */}
        <div className="w-full max-w-sm">
          {isSubmitted ? (
            <div className="flex flex-col items-center gap-6">
              <div className="flex size-20 items-center justify-center rounded-full bg-green-500/20">
                <CheckCircle className="size-10 text-green-500" />
              </div>
              <p className="text-center text-muted-foreground">
                {"We've sent a password reset link to "}
                <span className="font-medium text-foreground">{email}</span>
              </p>
              <Link
                href="/login"
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-4 font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
              >
                Back to Login
              </Link>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="flex flex-col gap-4">
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 size-5 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="email"
                  placeholder="Email address"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full rounded-xl border border-border bg-card py-4 pl-12 pr-4 text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
                />
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="flex items-center justify-center gap-2 rounded-xl bg-primary py-4 font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98] disabled:opacity-50"
              >
                {isLoading ? (
                  <div className="size-5 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
                ) : (
                  <span>Send Reset Link</span>
                )}
              </button>

              <Link
                href="/login"
                className="flex items-center justify-center gap-2 rounded-xl border border-border py-4 font-medium text-foreground transition-all hover:bg-secondary active:scale-[0.98]"
              >
                <ArrowLeft className="size-5" />
                <span>Back to Login</span>
              </Link>
            </form>
          )}
        </div>
      </div>
    </main>
  );
}
