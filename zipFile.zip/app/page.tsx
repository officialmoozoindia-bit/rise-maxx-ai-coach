import { Header } from "@/components/header";
import { WelcomeBanner } from "@/components/welcome-banner";
import { StatsOverview } from "@/components/stats-overview";
import { QuickActions } from "@/components/quick-actions";
import { SectionCards } from "@/components/section-cards";
import { DailyQuote } from "@/components/daily-quote";
import { BottomNav } from "@/components/bottom-nav";

export default function Home() {
  return (
    <div className="flex min-h-svh flex-col bg-background">
      <Header />
      <main className="flex-1 overflow-y-auto pb-24">
        <div className="mx-auto flex max-w-md flex-col gap-6 px-4 py-6">
          <WelcomeBanner />
          <StatsOverview />
          <QuickActions />
          <section>
            <h2 className="mb-3 text-lg font-semibold text-foreground">
              Explore
            </h2>
            <SectionCards />
          </section>
          <section>
            <h2 className="mb-3 text-lg font-semibold text-foreground">
              Daily Inspiration
            </h2>
            <DailyQuote />
          </section>
        </div>
      </main>
      <BottomNav />
    </div>
  );
}
