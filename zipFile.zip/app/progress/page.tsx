"use client";

import { ArrowLeft, BarChart3, TrendingUp, Calendar, Target } from "lucide-react";
import Link from "next/link";
import { BottomNav } from "@/components/bottom-nav";

const weeklyData = [
  { day: "Mon", value: 45 },
  { day: "Tue", value: 80 },
  { day: "Wed", value: 60 },
  { day: "Thu", value: 90 },
  { day: "Fri", value: 75 },
  { day: "Sat", value: 100 },
  { day: "Sun", value: 30 },
];

const categoryProgress = [
  { name: "Money & Business", progress: 35, color: "bg-primary" },
  { name: "Lookmaxxing", progress: 50, color: "bg-primary" },
  { name: "Mental Health", progress: 65, color: "bg-primary" },
  { name: "Fitness", progress: 25, color: "bg-primary" },
  { name: "Goals", progress: 80, color: "bg-primary" },
];

export default function ProgressPage() {
  const maxValue = Math.max(...weeklyData.map((d) => d.value));

  return (
    <div className="flex min-h-screen flex-col bg-background pb-20">
      <header className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-xl">
        <div className="flex items-center gap-4 px-4 py-3">
          <Link
            href="/"
            className="flex size-10 items-center justify-center rounded-full bg-secondary text-muted-foreground transition-colors hover:bg-secondary/80"
          >
            <ArrowLeft className="size-5" />
          </Link>
          <h1 className="text-lg font-bold text-foreground">Progress</h1>
        </div>
      </header>

      <main className="flex-1 px-4 py-6">
        <div className="grid grid-cols-2 gap-3">
          <div className="rounded-xl border border-border bg-card p-4">
            <div className="flex items-center gap-2 text-muted-foreground">
              <TrendingUp className="size-4" />
              <span className="text-xs">Total XP</span>
            </div>
            <p className="mt-2 text-2xl font-bold text-foreground">2,450</p>
            <p className="text-xs text-primary">+120 this week</p>
          </div>
          <div className="rounded-xl border border-border bg-card p-4">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Calendar className="size-4" />
              <span className="text-xs">Current Streak</span>
            </div>
            <p className="mt-2 text-2xl font-bold text-foreground">24 days</p>
            <p className="text-xs text-primary">Personal best!</p>
          </div>
          <div className="rounded-xl border border-border bg-card p-4">
            <div className="flex items-center gap-2 text-muted-foreground">
              <BarChart3 className="size-4" />
              <span className="text-xs">Lessons Done</span>
            </div>
            <p className="mt-2 text-2xl font-bold text-foreground">156</p>
            <p className="text-xs text-muted-foreground">12 this week</p>
          </div>
          <div className="rounded-xl border border-border bg-card p-4">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Target className="size-4" />
              <span className="text-xs">Goals Achieved</span>
            </div>
            <p className="mt-2 text-2xl font-bold text-foreground">8</p>
            <p className="text-xs text-muted-foreground">3 in progress</p>
          </div>
        </div>

        <div className="mt-6 rounded-xl border border-border bg-card p-4">
          <h2 className="font-semibold text-foreground">Weekly Activity</h2>
          <div className="mt-4 flex items-end justify-between gap-2 h-32">
            {weeklyData.map((item) => (
              <div key={item.day} className="flex flex-1 flex-col items-center gap-2">
                <div
                  className="w-full rounded-t bg-primary transition-all"
                  style={{ height: `${(item.value / maxValue) * 100}%` }}
                />
                <span className="text-xs text-muted-foreground">{item.day}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-6 rounded-xl border border-border bg-card p-4">
          <h2 className="font-semibold text-foreground">Category Progress</h2>
          <div className="mt-4 flex flex-col gap-4">
            {categoryProgress.map((category) => (
              <div key={category.name}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm text-muted-foreground">{category.name}</span>
                  <span className="text-sm text-primary">{category.progress}%</span>
                </div>
                <div className="h-2 rounded-full bg-secondary">
                  <div
                    className={`h-full rounded-full ${category.color} transition-all`}
                    style={{ width: `${category.progress}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>

      <BottomNav />
    </div>
  );
}
