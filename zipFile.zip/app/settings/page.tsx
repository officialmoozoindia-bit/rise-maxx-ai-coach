"use client";

import { ArrowLeft, Bell, Moon, Globe, Shield, HelpCircle, ChevronRight } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { BottomNav } from "@/components/bottom-nav";

export default function SettingsPage() {
  const [notifications, setNotifications] = useState(true);
  const [darkMode, setDarkMode] = useState(true);

  return (
    <div className="flex min-h-screen flex-col bg-background pb-20">
      <header className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-xl">
        <div className="flex items-center gap-4 px-4 py-3">
          <Link
            href="/"
            className="flex size-10 items-center justify-center rounded-full bg-secondary text-muted-foreground transition-colors hover:bg-secondary/80"
          >
            <ArrowLeft className="size-5" />
          </Link>
          <h1 className="text-lg font-bold text-foreground">Settings</h1>
        </div>
      </header>

      <main className="flex-1 px-4 py-6">
        <div className="flex flex-col gap-2">
          <div className="flex items-center justify-between rounded-xl border border-border bg-card p-4">
            <div className="flex items-center gap-3">
              <Bell className="size-5 text-muted-foreground" />
              <span className="font-medium text-foreground">Notifications</span>
            </div>
            <button
              onClick={() => setNotifications(!notifications)}
              className={`relative h-6 w-11 rounded-full transition-colors ${
                notifications ? "bg-primary" : "bg-secondary"
              }`}
            >
              <span
                className={`absolute top-1 size-4 rounded-full bg-white transition-transform ${
                  notifications ? "left-6" : "left-1"
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between rounded-xl border border-border bg-card p-4">
            <div className="flex items-center gap-3">
              <Moon className="size-5 text-muted-foreground" />
              <span className="font-medium text-foreground">Dark Mode</span>
            </div>
            <button
              onClick={() => setDarkMode(!darkMode)}
              className={`relative h-6 w-11 rounded-full transition-colors ${
                darkMode ? "bg-primary" : "bg-secondary"
              }`}
            >
              <span
                className={`absolute top-1 size-4 rounded-full bg-white transition-transform ${
                  darkMode ? "left-6" : "left-1"
                }`}
              />
            </button>
          </div>

          <Link
            href="/settings/language"
            className="flex items-center justify-between rounded-xl border border-border bg-card p-4 transition-all hover:border-primary/50 active:scale-[0.98]"
          >
            <div className="flex items-center gap-3">
              <Globe className="size-5 text-muted-foreground" />
              <span className="font-medium text-foreground">Language</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">English</span>
              <ChevronRight className="size-5 text-muted-foreground" />
            </div>
          </Link>

          <Link
            href="/settings/privacy"
            className="flex items-center justify-between rounded-xl border border-border bg-card p-4 transition-all hover:border-primary/50 active:scale-[0.98]"
          >
            <div className="flex items-center gap-3">
              <Shield className="size-5 text-muted-foreground" />
              <span className="font-medium text-foreground">Privacy & Security</span>
            </div>
            <ChevronRight className="size-5 text-muted-foreground" />
          </Link>

          <Link
            href="/settings/help"
            className="flex items-center justify-between rounded-xl border border-border bg-card p-4 transition-all hover:border-primary/50 active:scale-[0.98]"
          >
            <div className="flex items-center gap-3">
              <HelpCircle className="size-5 text-muted-foreground" />
              <span className="font-medium text-foreground">Help & Support</span>
            </div>
            <ChevronRight className="size-5 text-muted-foreground" />
          </Link>
        </div>

        <div className="mt-8 text-center">
          <p className="text-sm text-muted-foreground">RiseMaxx v1.0.0</p>
          <p className="text-xs text-muted-foreground">Made with care for Indian teens</p>
        </div>
      </main>

      <BottomNav />
    </div>
  );
}
