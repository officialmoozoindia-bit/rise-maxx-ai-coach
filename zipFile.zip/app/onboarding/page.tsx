"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  ArrowRight,
  ArrowLeft,
  Sparkles,
  Target,
  TrendingUp,
  Brain,
  Dumbbell,
  Heart,
  Zap,
} from "lucide-react";

const goals = [
  {
    id: "money",
    title: "Earn Money",
    description: "Start earning, learn investing & build wealth",
    icon: TrendingUp,
  },
  {
    id: "fitness",
    title: "Get Fit",
    description: "Build muscle, lose fat & feel energetic",
    icon: Dumbbell,
  },
  {
    id: "mental",
    title: "Mental Peace",
    description: "Reduce anxiety, build confidence & stay calm",
    icon: Brain,
  },
  {
    id: "looks",
    title: "Look Better",
    description: "Improve style, skincare & overall appearance",
    icon: Sparkles,
  },
  {
    id: "goals",
    title: "Achieve Goals",
    description: "Stay focused, track progress & crush targets",
    icon: Target,
  },
  {
    id: "all",
    title: "All of the Above",
    description: "I want to level up in every area of my life",
    icon: Zap,
  },
];

const ageRanges = ["13-15", "16-17", "18-19"];

export default function OnboardingPage() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [selectedGoal, setSelectedGoal] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const totalSteps = 3;

  const handleNext = () => {
    if (step < totalSteps) {
      setStep(step + 1);
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  const handleComplete = () => {
    setIsLoading(true);
    
    // Save onboarding data to localStorage
    const userData = {
      name,
      age,
      mainGoal: selectedGoal,
      onboardingCompleted: true,
      completedAt: new Date().toISOString(),
    };
    localStorage.setItem("risemaxx_user", JSON.stringify(userData));
    
    // Navigate to home
    setTimeout(() => {
      router.push("/");
    }, 1500);
  };

  const canProceed = () => {
    switch (step) {
      case 1:
        return name.trim().length >= 2;
      case 2:
        return age !== "";
      case 3:
        return selectedGoal !== "";
      default:
        return false;
    }
  };

  return (
    <div className="flex min-h-svh flex-col bg-background">
      {/* Progress Bar */}
      <div className="fixed left-0 right-0 top-0 z-50 bg-background/80 backdrop-blur-sm">
        <div className="mx-auto flex max-w-md items-center gap-4 px-4 py-4">
          {step > 1 && (
            <button
              onClick={handleBack}
              className="rounded-full p-2 text-muted-foreground transition-colors hover:bg-card hover:text-foreground"
            >
              <ArrowLeft className="size-5" />
            </button>
          )}
          <div className="flex flex-1 gap-2">
            {Array.from({ length: totalSteps }).map((_, i) => (
              <div
                key={i}
                className={`h-1.5 flex-1 rounded-full transition-all duration-300 ${
                  i < step ? "bg-primary" : "bg-card"
                }`}
              />
            ))}
          </div>
          <Link
            href="/"
            className="text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            Skip
          </Link>
        </div>
      </div>

      <main className="flex flex-1 flex-col px-4 pb-8 pt-20">
        <div className="mx-auto flex w-full max-w-md flex-1 flex-col">
          {/* Step 1: Name */}
          {step === 1 && (
            <div className="flex flex-1 flex-col">
              <div className="mb-8">
                <div className="mb-4 flex size-16 items-center justify-center rounded-2xl bg-primary/10">
                  <Heart className="size-8 text-primary" />
                </div>
                <h1 className="mb-2 text-2xl font-bold text-foreground">
                  Welcome to RiseMaxx
                </h1>
                <p className="text-muted-foreground">
                  Let&apos;s personalize your experience. What should we call you?
                </p>
              </div>

              <div className="flex-1">
                <label className="mb-2 block text-sm font-medium text-foreground">
                  Your Name
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Enter your name"
                  className="w-full rounded-xl border border-border bg-card px-4 py-4 text-lg text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
                  autoFocus
                />
                <p className="mt-2 text-sm text-muted-foreground">
                  This is how your AI coach will address you
                </p>
              </div>
            </div>
          )}

          {/* Step 2: Age */}
          {step === 2 && (
            <div className="flex flex-1 flex-col">
              <div className="mb-8">
                <div className="mb-4 flex size-16 items-center justify-center rounded-2xl bg-primary/10">
                  <Sparkles className="size-8 text-primary" />
                </div>
                <h1 className="mb-2 text-2xl font-bold text-foreground">
                  Hey {name}! How old are you?
                </h1>
                <p className="text-muted-foreground">
                  We&apos;ll customize advice based on your age group
                </p>
              </div>

              <div className="flex flex-1 flex-col gap-3">
                {ageRanges.map((range) => (
                  <button
                    key={range}
                    onClick={() => setAge(range)}
                    className={`flex items-center justify-between rounded-xl border p-4 text-left transition-all active:scale-[0.98] ${
                      age === range
                        ? "border-primary bg-primary/10"
                        : "border-border bg-card hover:border-primary/50"
                    }`}
                  >
                    <span
                      className={`text-lg font-medium ${
                        age === range ? "text-primary" : "text-foreground"
                      }`}
                    >
                      {range} years old
                    </span>
                    <div
                      className={`flex size-6 items-center justify-center rounded-full border-2 ${
                        age === range
                          ? "border-primary bg-primary"
                          : "border-muted-foreground"
                      }`}
                    >
                      {age === range && (
                        <div className="size-2 rounded-full bg-primary-foreground" />
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Step 3: Main Goal */}
          {step === 3 && (
            <div className="flex flex-1 flex-col">
              <div className="mb-6">
                <div className="mb-4 flex size-16 items-center justify-center rounded-2xl bg-primary/10">
                  <Target className="size-8 text-primary" />
                </div>
                <h1 className="mb-2 text-2xl font-bold text-foreground">
                  What&apos;s your main goal?
                </h1>
                <p className="text-muted-foreground">
                  Pick one to focus on first. You can explore everything later.
                </p>
              </div>

              <div className="flex flex-1 flex-col gap-3">
                {goals.map((goal) => {
                  const Icon = goal.icon;
                  return (
                    <button
                      key={goal.id}
                      onClick={() => setSelectedGoal(goal.id)}
                      className={`flex items-center gap-4 rounded-xl border p-4 text-left transition-all active:scale-[0.98] ${
                        selectedGoal === goal.id
                          ? "border-primary bg-primary/10"
                          : "border-border bg-card hover:border-primary/50"
                      }`}
                    >
                      <div
                        className={`flex size-12 items-center justify-center rounded-xl ${
                          selectedGoal === goal.id
                            ? "bg-primary/20"
                            : "bg-muted/50"
                        }`}
                      >
                        <Icon
                          className={`size-6 ${
                            selectedGoal === goal.id
                              ? "text-primary"
                              : "text-muted-foreground"
                          }`}
                        />
                      </div>
                      <div className="flex-1">
                        <h3
                          className={`font-semibold ${
                            selectedGoal === goal.id
                              ? "text-primary"
                              : "text-foreground"
                          }`}
                        >
                          {goal.title}
                        </h3>
                        <p className="text-sm text-muted-foreground">
                          {goal.description}
                        </p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Next/Complete Button */}
          <div className="mt-6">
            {step < totalSteps ? (
              <button
                onClick={handleNext}
                disabled={!canProceed()}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-4 font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50"
              >
                <span>Continue</span>
                <ArrowRight className="size-5" />
              </button>
            ) : (
              <button
                onClick={handleComplete}
                disabled={!canProceed() || isLoading}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-4 font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50"
              >
                {isLoading ? (
                  <>
                    <div className="size-5 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
                    <span>Setting up your experience...</span>
                  </>
                ) : (
                  <>
                    <span>Start My Journey</span>
                    <Sparkles className="size-5" />
                  </>
                )}
              </button>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
