"use client";

import { ArrowLeft, Sparkles, Play, Lock, CheckCircle2 } from "lucide-react";
import Link from "next/link";
import { BottomNav } from "@/components/bottom-nav";

const lessons = [
  { id: 1, title: "Building a Skincare Routine", duration: "10 min", completed: true, locked: false },
  { id: 2, title: "Haircare Basics for Teens", duration: "8 min", completed: true, locked: false },
  { id: 3, title: "Finding Your Personal Style", duration: "12 min", completed: false, locked: false },
  { id: 4, title: "Grooming Essentials", duration: "7 min", completed: false, locked: false },
  { id: 5, title: "Posture & Body Language", duration: "15 min", completed: false, locked: false },
  { id: 6, title: "Building Confidence", duration: "10 min", completed: false, locked: true },
  { id: 7, title: "Wardrobe on a Budget", duration: "12 min", completed: false, locked: true },
  { id: 8, title: "First Impressions Matter", duration: "8 min", completed: false, locked: true },
];

export default function LookmaxxingPage() {
  const completedCount = lessons.filter((l) => l.completed).length;
  const progress = (completedCount / lessons.length) * 100;

  return (
    <div className="flex min-h-screen flex-col bg-background pb-20">
      <header className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-xl">
        <div className="flex items-center gap-4 px-4 py-3">
          <Link
            href="/"
            className="flex size-10 items-center justify-center rounded-full bg-secondary text-muted-foreground transition-colors hover:bg-secondary/80"
          >
            <ArrowLeft className="size-5" />
          </Link>
          <div className="flex-1">
            <h1 className="text-lg font-bold text-foreground">Lookmaxxing</h1>
            <p className="text-xs text-muted-foreground">{completedCount} of {lessons.length} lessons completed</p>
          </div>
          <div className="flex size-12 items-center justify-center rounded-lg bg-primary/10 text-primary">
            <Sparkles className="size-6" />
          </div>
        </div>
      </header>

      <main className="flex-1 px-4 py-6">
        <div className="mb-6 rounded-xl border border-border bg-card p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-foreground">Your Progress</span>
            <span className="text-sm text-primary">{Math.round(progress)}%</span>
          </div>
          <div className="h-2 rounded-full bg-secondary">
            <div
              className="h-full rounded-full bg-primary transition-all"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        <div className="flex flex-col gap-3">
          {lessons.map((lesson, index) => (
            <Link
              key={lesson.id}
              href={lesson.locked ? "#" : `/sections/lookmaxxing/lesson/${lesson.id}`}
              className={`group flex items-center gap-4 rounded-xl border border-border bg-card p-4 transition-all ${
                lesson.locked
                  ? "opacity-50 cursor-not-allowed"
                  : "hover:border-primary/50 active:scale-[0.98]"
              }`}
            >
              <div
                className={`flex size-10 shrink-0 items-center justify-center rounded-full ${
                  lesson.completed
                    ? "bg-primary text-primary-foreground"
                    : lesson.locked
                    ? "bg-secondary text-muted-foreground"
                    : "bg-primary/10 text-primary"
                }`}
              >
                {lesson.completed ? (
                  <CheckCircle2 className="size-5" />
                ) : lesson.locked ? (
                  <Lock className="size-4" />
                ) : (
                  <span className="text-sm font-bold">{index + 1}</span>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-medium text-foreground truncate">{lesson.title}</h3>
                <p className="text-sm text-muted-foreground">{lesson.duration}</p>
              </div>
              {!lesson.locked && !lesson.completed && (
                <Play className="size-5 text-primary opacity-0 transition-opacity group-hover:opacity-100" />
              )}
            </Link>
          ))}
        </div>
      </main>

      <BottomNav />
    </div>
  );
}
