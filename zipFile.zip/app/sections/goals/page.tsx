"use client";

import { ArrowLeft, Target, Plus, CheckCircle2, Circle, Trophy, Calendar } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { BottomNav } from "@/components/bottom-nav";

interface Goal {
  id: number;
  title: string;
  category: string;
  progress: number;
  target: number;
  unit: string;
  completed: boolean;
}

const initialGoals: Goal[] = [
  { id: 1, title: "Save for new phone", category: "Money", progress: 8500, target: 15000, unit: "INR", completed: false },
  { id: 2, title: "Complete 30 workouts", category: "Fitness", progress: 12, target: 30, unit: "workouts", completed: false },
  { id: 3, title: "Read 5 books this month", category: "Personal", progress: 2, target: 5, unit: "books", completed: false },
  { id: 4, title: "Learn basic coding", category: "Skills", progress: 100, target: 100, unit: "%", completed: true },
];

export default function GoalsPage() {
  const [goals] = useState<Goal[]>(initialGoals);
  const completedGoals = goals.filter((g) => g.completed).length;

  return (
    <div className="flex min-h-screen flex-col bg-background pb-20">
      <header className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-xl">
        <div className="flex items-center gap-4 px-4 py-3">
          <Link
            href="/"
            className="flex size-10 items-center justify-center rounded-full bg-secondary text-muted-foreground transition-colors hover:bg-secondary/80"
          >
            <ArrowLeft className="size-5" />
          </Link>
          <div className="flex-1">
            <h1 className="text-lg font-bold text-foreground">Goals Tracker</h1>
            <p className="text-xs text-muted-foreground">{completedGoals} of {goals.length} goals achieved</p>
          </div>
          <div className="flex size-12 items-center justify-center rounded-lg bg-primary/10 text-primary">
            <Target className="size-6" />
          </div>
        </div>
      </header>

      <main className="flex-1 px-4 py-6">
        <div className="mb-6 flex gap-3">
          <div className="flex-1 rounded-xl border border-border bg-card p-4 text-center">
            <Trophy className="mx-auto size-6 text-primary" />
            <p className="mt-2 text-2xl font-bold text-foreground">{completedGoals}</p>
            <p className="text-xs text-muted-foreground">Achieved</p>
          </div>
          <div className="flex-1 rounded-xl border border-border bg-card p-4 text-center">
            <Calendar className="mx-auto size-6 text-primary" />
            <p className="mt-2 text-2xl font-bold text-foreground">{goals.length - completedGoals}</p>
            <p className="text-xs text-muted-foreground">In Progress</p>
          </div>
        </div>

        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-foreground">Your Goals</h2>
          <Link
            href="/sections/goals/new"
            className="flex items-center gap-1 rounded-lg bg-primary px-3 py-2 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90 active:scale-[0.98]"
          >
            <Plus className="size-4" />
            <span>Add Goal</span>
          </Link>
        </div>

        <div className="flex flex-col gap-3">
          {goals.map((goal) => {
            const progressPercent = (goal.progress / goal.target) * 100;
            return (
              <Link
                key={goal.id}
                href={`/sections/goals/${goal.id}`}
                className="group rounded-xl border border-border bg-card p-4 transition-all hover:border-primary/50 active:scale-[0.98]"
              >
                <div className="flex items-start gap-3">
                  <div className="mt-0.5">
                    {goal.completed ? (
                      <CheckCircle2 className="size-5 text-primary" />
                    ) : (
                      <Circle className="size-5 text-muted-foreground" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <h3 className={`font-medium truncate ${goal.completed ? "text-muted-foreground line-through" : "text-foreground"}`}>
                        {goal.title}
                      </h3>
                      <span className="shrink-0 text-xs rounded-full bg-secondary px-2 py-1 text-muted-foreground">
                        {goal.category}
                      </span>
                    </div>
                    <div className="mt-3">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm text-muted-foreground">
                          {goal.progress.toLocaleString()} / {goal.target.toLocaleString()} {goal.unit}
                        </span>
                        <span className="text-sm text-primary">{Math.round(progressPercent)}%</span>
                      </div>
                      <div className="h-2 rounded-full bg-secondary">
                        <div
                          className="h-full rounded-full bg-primary transition-all"
                          style={{ width: `${Math.min(progressPercent, 100)}%` }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </main>

      <BottomNav />
    </div>
  );
}
