"use client";

import { useEffect, useState } from "react";
import { useRouter, usePathname } from "next/navigation";

const publicPaths = ["/login", "/signup", "/forgot-password", "/onboarding"];

export function OnboardingCheck({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const [isChecking, setIsChecking] = useState(true);
  const [shouldRender, setShouldRender] = useState(false);

  useEffect(() => {
    const checkOnboarding = () => {
      // Skip check for public paths
      if (publicPaths.includes(pathname)) {
        setIsChecking(false);
        setShouldRender(true);
        return;
      }

      const userData = localStorage.getItem("risemaxx_user");
      
      if (!userData) {
        // No user data, redirect to onboarding
        router.push("/onboarding");
        return;
      }

      try {
        const parsed = JSON.parse(userData);
        if (!parsed.onboardingCompleted) {
          router.push("/onboarding");
          return;
        }
      } catch {
        // Invalid data, redirect to onboarding
        router.push("/onboarding");
        return;
      }

      // Onboarding completed, render children
      setIsChecking(false);
      setShouldRender(true);
    };

    checkOnboarding();
  }, [pathname, router]);

  if (isChecking && !publicPaths.includes(pathname)) {
    return (
      <div className="flex min-h-svh items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="size-10 animate-spin rounded-full border-3 border-primary border-t-transparent" />
          <p className="text-sm text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!shouldRender && !publicPaths.includes(pathname)) {
    return null;
  }

  return <>{children}</>;
}
