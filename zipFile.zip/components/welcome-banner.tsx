"use client";

import { useEffect, useState } from "react";
import { ArrowRight } from "lucide-react";
import Link from "next/link";

export function WelcomeBanner() {
  const [userName, setUserName] = useState("");
  
  useEffect(() => {
    const userData = localStorage.getItem("risemaxx_user");
    if (userData) {
      try {
        const parsed = JSON.parse(userData);
        setUserName(parsed.name || "");
      } catch {
        // ignore
      }
    }
  }, []);

  const hour = new Date().getHours();
  let greeting = "Good morning";
  if (hour >= 12 && hour < 17) greeting = "Good afternoon";
  else if (hour >= 17) greeting = "Good evening";

  return (
    <div className="relative overflow-hidden rounded-xl bg-gradient-to-br from-primary/20 via-primary/10 to-transparent border border-primary/20 p-4">
      <div className="relative z-10">
        <p className="text-sm text-muted-foreground">
          {greeting}{userName ? `, ${userName}` : ""}
        </p>
        <h2 className="mt-1 text-xl font-bold text-foreground">
          Ready to level up today?
        </h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Complete your daily habits to maintain your streak
        </p>
        <Link 
          href="/daily-challenge"
          className="mt-4 inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90 active:scale-[0.98]"
        >
          <span>Start Daily Challenge</span>
          <ArrowRight className="size-4" />
        </Link>
      </div>
      <div className="absolute -bottom-8 -right-8 size-32 rounded-full bg-primary/10 blur-2xl" />
    </div>
  );
}
