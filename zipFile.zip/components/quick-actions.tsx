"use client";

import { MessageCircle, Sparkles } from "lucide-react";
import Link from "next/link";

export function QuickActions() {
  return (
    <div className="flex gap-3">
      <Link
        href="/chat"
        className="group flex flex-1 items-center justify-center gap-2 rounded-xl bg-primary py-4 font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
      >
        <MessageCircle className="size-5" />
        <span>Chat with AI</span>
      </Link>
      <button className="group flex flex-1 items-center justify-center gap-2 rounded-xl border border-primary/50 bg-primary/10 py-4 font-semibold text-primary transition-all hover:bg-primary/20 active:scale-[0.98]">
        <Sparkles className="size-5" />
        <span>Daily Tips</span>
      </button>
    </div>
  );
}
