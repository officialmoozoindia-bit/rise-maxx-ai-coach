"use client";

import { User, Bell, Settings } from "lucide-react";
import Link from "next/link";
import { useState } from "react";

export function Header() {
  const [hasNotifications] = useState(true);

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-xl">
      <div className="flex items-center justify-between px-4 py-3">
        <Link href="/" className="flex items-center gap-3">
          <div className="flex size-10 items-center justify-center rounded-full bg-primary">
            <span className="text-lg font-bold text-primary-foreground">R</span>
          </div>
          <div>
            <h1 className="text-lg font-bold text-foreground">RiseMaxx</h1>
            <p className="text-xs text-muted-foreground">AI Life Coach</p>
          </div>
        </Link>
        <div className="flex items-center gap-2">
          <Link 
            href="/notifications"
            className="relative flex size-10 items-center justify-center rounded-full bg-secondary text-muted-foreground transition-colors hover:bg-secondary/80 hover:text-foreground"
          >
            <Bell className="size-5" />
            {hasNotifications && (
              <span className="absolute right-2 top-2 size-2 rounded-full bg-primary" />
            )}
          </Link>
          <Link 
            href="/settings"
            className="flex size-10 items-center justify-center rounded-full bg-secondary text-muted-foreground transition-colors hover:bg-secondary/80 hover:text-foreground"
          >
            <Settings className="size-5" />
          </Link>
          <Link 
            href="/profile"
            className="flex size-10 items-center justify-center rounded-full bg-primary text-primary-foreground transition-opacity hover:opacity-80"
          >
            <User className="size-5" />
          </Link>
        </div>
      </div>
    </header>
  );
}
