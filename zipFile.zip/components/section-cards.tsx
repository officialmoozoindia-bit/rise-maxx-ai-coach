"use client";

import {
  TrendingUp,
  Sparkles,
  Brain,
  Dumbbell,
  Target,
  ChevronRight,
} from "lucide-react";
import Link from "next/link";

interface Section {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  stats: string;
  href: string;
}

const sections: Section[] = [
  {
    id: "money",
    title: "Money & Business",
    description: "Master personal finance, start side hustles & build wealth early",
    icon: <TrendingUp className="size-6" />,
    stats: "24 lessons",
    href: "/sections/money",
  },
  {
    id: "lookmaxxing",
    title: "Lookmaxxing",
    description: "Upgrade your style, skincare routine & overall appearance",
    icon: <Sparkles className="size-6" />,
    stats: "18 lessons",
    href: "/sections/lookmaxxing",
  },
  {
    id: "mental",
    title: "Mental Health & Anxiety",
    description: "Manage stress, overcome anxiety & build emotional resilience",
    icon: <Brain className="size-6" />,
    stats: "32 lessons",
    href: "/sections/mental",
  },
  {
    id: "fitness",
    title: "Fitness & Workout",
    description: "Home workouts, gym routines & nutrition plans for teens",
    icon: <Dumbbell className="size-6" />,
    stats: "45 lessons",
    href: "/sections/fitness",
  },
  {
    id: "goals",
    title: "Goals Tracker",
    description: "Set SMART goals, track progress & celebrate achievements",
    icon: <Target className="size-6" />,
    stats: "12 lessons",
    href: "/sections/goals",
  },
];

export function SectionCards() {
  return (
    <div className="flex flex-col gap-3">
      {sections.map((section) => (
        <Link
          key={section.id}
          href={section.href}
          className="group relative w-full overflow-hidden rounded-xl border border-border bg-card p-4 text-left transition-all duration-300 hover:border-primary/50 hover:bg-card/80 active:scale-[0.98]"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-primary/5 opacity-0 transition-opacity group-hover:opacity-100" />
          <div className="relative flex items-center gap-4">
            <div className="flex size-12 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
              {section.icon}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <h3 className="font-semibold text-foreground truncate">
                  {section.title}
                </h3>
                <span className="shrink-0 text-xs text-muted-foreground">
                  {section.stats}
                </span>
              </div>
              <p className="mt-1 text-sm text-muted-foreground line-clamp-1">
                {section.description}
              </p>
            </div>
            <ChevronRight className="size-5 shrink-0 text-muted-foreground transition-transform group-hover:translate-x-1 group-hover:text-primary" />
          </div>
        </Link>
      ))}
    </div>
  );
}
