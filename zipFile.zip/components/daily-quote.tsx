"use client";

import { Quote } from "lucide-react";

const quotes = [
  {
    text: "Success is not final, failure is not fatal: it is the courage to continue that counts.",
    author: "Winston Churchill",
  },
  {
    text: "The only way to do great work is to love what you do.",
    author: "Steve Jobs",
  },
  {
    text: "Your time is limited, don&apos;t waste it living someone else&apos;s life.",
    author: "Steve Jobs",
  },
];

export function DailyQuote() {
  const todayQuote = quotes[new Date().getDay() % quotes.length];

  return (
    <div className="relative overflow-hidden rounded-xl border border-border bg-card p-4">
      <div className="absolute -right-4 -top-4 text-primary/10">
        <Quote className="size-24" />
      </div>
      <div className="relative">
        <p className="text-sm leading-relaxed text-muted-foreground italic">
          &ldquo;{todayQuote.text}&rdquo;
        </p>
        <p className="mt-2 text-xs font-medium text-primary">
          — {todayQuote.author}
        </p>
      </div>
    </div>
  );
}
