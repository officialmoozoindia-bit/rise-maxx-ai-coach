"use client";

import { Flame, Trophy, Star } from "lucide-react";

interface StatCardProps {
  icon: React.ReactNode;
  value: string;
  label: string;
}

function StatCard({ icon, value, label }: StatCardProps) {
  return (
    <div className="flex flex-col items-center justify-center rounded-xl border border-border bg-card p-4">
      <div className="mb-2 text-primary">{icon}</div>
      <span className="text-xl font-bold text-foreground">{value}</span>
      <span className="text-xs text-muted-foreground">{label}</span>
    </div>
  );
}

export function StatsOverview() {
  return (
    <div className="grid grid-cols-3 gap-3">
      <StatCard
        icon={<Flame className="size-5" />}
        value="7"
        label="Day Streak"
      />
      <StatCard
        icon={<Trophy className="size-5" />}
        value="12"
        label="Achievements"
      />
      <StatCard icon={<Star className="size-5" />} value="850" label="XP" />
    </div>
  );
}
